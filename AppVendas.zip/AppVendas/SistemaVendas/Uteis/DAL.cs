﻿using MySql.Data.MySqlClient;
using System.Data;


namespace SistemaVendas.Uteis
{
    public class DAL
    {
        private static string Server = "localhost";
        private static string Database = "sistema_venda";
        private static string User = "dev";
        private static string Password = "48752Drx";
        private static string ConnectionString = $"Server={Server}; Database={Database};Uid={User};Pwd={Password};Sslmode=none;Charset=utf8;";

        //varialvel do objeto d bco de dados
        private static MySqlConnection Connection;

        public DAL()
        {
            Connection = new MySqlConnection(ConnectionString);
            Connection.Open();
        }

        //Espera um parametro do tipo string contendo comando Sql tipo  SELECT
        public DataTable RetDataTable(string sql)
        {
            DataTable data = new DataTable();
            MySqlCommand Command = new MySqlCommand(sql, Connection);
            MySqlDataAdapter da = new MySqlDataAdapter(Command);
            da.Fill(data);
            return data;
        }

        //espera uma string para comandos  CRUD
        public void ExecutarComandoSQL(string sql)
        {
            MySqlCommand Command = new MySqlCommand(sql, Connection);
            Command.ExecuteNonQuery();
        }
    }
}
