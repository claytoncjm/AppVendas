﻿using SistemaVendas.Uteis;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Data;
using System.Linq;
using System.Threading.Tasks;

namespace SistemaVendas.Models
{
    public class VendedorModel
    {
        public string Id { get; set; }
        [Required(ErrorMessage = "Informe o nome do Vendedor")]
        public string Nome { get; set; }
        [Required(ErrorMessage = "Informe o Email do Vendedor")]
       
        public string Email { get; set; }

        public string Senha { get; set; }



        // listando todos os Vendedores recuperando os dados do banco
        public List<VendedorModel> ListarTodosVendedores()
        {
            List<VendedorModel> lista = new List<VendedorModel>();
            VendedorModel item;
            //criando uma estancia para conexao com o banco
            DAL objDAL = new DAL();
            //consutando os dados dobanco e trazendo de forma crescente
            string sql = "SELECT id, nome, email FROM Vendedor ORDER BY  NOME asc";
            DataTable dt = objDAL.RetDataTable(sql);

            for (int i = 0; i < dt.Rows.Count; i++)
            {
                //criando uma interação preenchdo as linhas
                item = new VendedorModel
                {
                    Id = dt.Rows[i]["id"].ToString(),
                    Nome = dt.Rows[i]["nome"].ToString(),
                    Email = dt.Rows[i]["email"].ToString(),
                    
                };
                lista.Add(item);
            }
            return lista;
        }


        public VendedorModel RetornarVendedor(int? id)
        {
            
            VendedorModel item;            
            DAL objDAL = new DAL();            
            string sql = $"SELECT id, nome, email, senha FROM Vendedor where id = '{id}' ORDER BY  NOME asc";
            DataTable dt = objDAL.RetDataTable(sql);                     
            
            item = new VendedorModel
                {
                    Id = dt.Rows[0]["id"].ToString(),
                    Nome = dt.Rows[0]["nome"].ToString(),
                    Email = dt.Rows[0]["email"].ToString(),
                    Senha = dt.Rows[0]["Senha"].ToString(),
                };
            return item;
        }
        //Insert ou UpDate
        public void Gravar()
        {
            DAL objDAL = new DAL();
            string sql = string.Empty;

            if (Id !=null)
            {
                 sql = $"UPDATE Vendedor SET NOME='{Nome}',EMAIL='{Email}' where id = '{Id}'"; 
            }
            else
            {
                 sql = $"INSERT INTO Vendedor(NOME, EMAIL, SENHA) VALUES ('{Nome}','{Email}','123456')";
            }
            
            objDAL.ExecutarComandoSQL(sql);
        }

        //metodo de exclusao 
        public void Excluir(int id)
        {
            DAL objDAL = new DAL();
            string sql = $"DELETE FROM Vendedor WHERE ID= '{id}'";
            objDAL.ExecutarComandoSQL(sql);
        }

    }
}
