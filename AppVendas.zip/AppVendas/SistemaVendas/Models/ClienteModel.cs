﻿using SistemaVendas.Uteis;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Data;
using System.Linq;
using System.Threading.Tasks;

namespace SistemaVendas.Models
{
    public class ClienteModel
    {
        public string Id { get; set; }
        [Required(ErrorMessage ="Informe o nome do cliente")]
        public string Nome { get; set; }
        [Required(ErrorMessage = "Informe o Cpf do cliente")]
        public string CPF  { get; set; }
        [Required(ErrorMessage = "Informe o Email do cliente")]
        public string Email { get; set; }

        public string Senha { get; set; }



        // listando todos os cliente recuperando os dados do banco
        public List<ClienteModel>ListarTodosClientes()
        {
            List<ClienteModel> lista = new List<ClienteModel>();
            ClienteModel item;
            //criando uma estancia para conexao com o banco
            DAL objDAL = new DAL();
            //consutando os dados dobanco e trazendo de forma crescente
            string sql = "SELECT id, nome, cpf_cnpj, email FROM cliente ORDER BY  NOME asc";
            DataTable dt = objDAL.RetDataTable(sql);

            for (int i = 0; i < dt.Rows.Count; i++)
            {
                //criando uma interação preenchdo as linhas
                item = new ClienteModel
                {
                    Id = dt.Rows[i]["id"].ToString(),
                    Nome = dt.Rows[i]["nome"].ToString(),
                    CPF = dt.Rows[i]["cpf_cnpj"].ToString(),
                    Email = dt.Rows[i]["email"].ToString(),
                    
                };
                lista.Add(item);
            }
            return lista;
        }


        public ClienteModel RetornarCliente(int? id)
        {
            
            ClienteModel item;            
            DAL objDAL = new DAL();            
            string sql = $"SELECT id, nome, cpf_cnpj, email, senha FROM Cliente where id = '{id}' ORDER BY  NOME asc";
            DataTable dt = objDAL.RetDataTable(sql);                     
            
            item = new ClienteModel
                {
                    Id = dt.Rows[0]["id"].ToString(),
                    Nome = dt.Rows[0]["nome"].ToString(),
                    CPF = dt.Rows[0]["cpf_cnpj"].ToString(),
                    Email = dt.Rows[0]["email"].ToString(),
                    Senha = dt.Rows[0]["Senha"].ToString(),
                };
            return item;
        }
        //Insert ou UpDate
        public void Gravar()
        {
            DAL objDAL = new DAL();
            string sql = string.Empty;

            if (Id !=null)
            {
                 sql = $"UPDADE CLIENTE SET NOME='{Nome}',CPF_CNPJ='{CPF}, EMAIL='{Email}' where id = '{Id}'"; 
            }
            else
            {
                 sql = $"INSERT INTO CLIENTE(NOME, CPF_CNPJ, EMAIL, SENHA) VALUES ('{Nome}','{CPF}','{Email}','123456')";
            }
            
            objDAL.ExecutarComandoSQL(sql);
        }

        //metodo de exclusao 
        public void Excluir(int id)
        {
            DAL objDAL = new DAL();
            string sql = $"DELETE FROM CLIENTE WHERE ID= '{id}'";
            objDAL.ExecutarComandoSQL(sql);
        }

    }
}
